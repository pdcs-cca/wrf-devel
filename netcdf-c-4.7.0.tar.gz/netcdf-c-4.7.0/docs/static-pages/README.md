This directory contains static html pages that live under http://www.unidata.ucar.edu/software/netcdf, but are not part of/packaged with the generated documentation.  
